const { chromium } = require('playwright');
const fs = require('node:fs/promises');
const path = require('node:path');
const assert = require('node:assert/strict');

const output = path.resolve(__dirname, '..');
const root = path.resolve(output, '../..');
const api = 'http://localhost:8000';
const web = 'http://localhost:5173';
const checks = [];
const issues = [];
const record = (name, detail) => { checks.push({ name, detail, passed: true }); console.log(`PASS: ${name}`); };

(async () => {
  const browser = await chromium.launch({
    headless: true,
    executablePath: path.join(process.env.LOCALAPPDATA, 'ms-playwright/chromium-1248/chrome-win64/chrome.exe'),
  });
  const context = await browser.newContext({ viewport: { width: 1600, height: 1100 }, deviceScaleFactor: 1 });
  const page = await context.newPage();
  page.on('pageerror', err => issues.push({ type: 'pageerror', message: err.message }));
  page.on('console', msg => { if (msg.type() === 'error') issues.push({ type: 'console', message: msg.text() }); });
  page.on('response', response => { if (response.status() >= 500) issues.push({ type: 'http', status: response.status(), url: response.url() }); });
  const screenshot = async (file, fullPage = true) => {
    await page.screenshot({ path: path.join(output, file), fullPage, animations: 'disabled' });
  };
  try {
    const ready = await context.request.get(`${api}/health/ready`);
    assert.equal(ready.status(), 200);
    record('Backend readiness and model load', await ready.json());
    assert.equal((await context.request.get(`${api}/api/v1/capacity`)).status(), 401);
    record('Unauthenticated API access rejected', 'HTTP 401');
    await page.goto(web);
    await page.getByRole('heading', { name: 'Welcome to HealthFlow' }).waitFor();
    await screenshot('01-login.png');
    await page.getByRole('button', { name: 'Sign in', exact: true }).click();
    await page.getByRole('heading', { name: 'Good morning, operations team' }).waitFor();
    await page.locator('.stats strong').first().filter({ hasText: '%' }).waitFor();
    record('Frontend login and authenticated dashboard', 'Real credentials and API session');
    await screenshot('02-overview.png');

    const token = await page.evaluate(() => localStorage.getItem('healthflow_token'));
    const headers = { Authorization: `Bearer ${token}` };
    const jsonGet = async route => {
      const r = await context.request.get(`${api}/api/v1${route}`, { headers });
      assert.equal(r.status(), 200, route);
      return r.json();
    };
    const endpointResults = {};
    for (const route of ['/auth/me', '/model/status', '/model/metrics', '/model/benchmarks', '/capacity', '/policies', '/forecasts/history', '/simulations', '/optimisations', '/operations-intelligence/status']) {
      const body = await jsonGet(route);
      endpointResults[route] = Array.isArray(body) ? { count: body.length } : body;
    }
    record('Authenticated read endpoints', endpointResults);

    await page.getByRole('link', { name: 'Model performance', exact: true }).click();
    await page.locator('tbody tr').first().waitFor();
    await screenshot('03-model-performance.png');
    record('Model metrics and benchmark table render', await page.locator('.stats').innerText());

    await page.getByRole('link', { name: 'Simulation', exact: true }).click();
    const simResponse = page.waitForResponse(r => r.url().endsWith('/simulations') && r.request().method() === 'POST');
    await page.getByRole('button', { name: 'Run 20 replications' }).click();
    const sim = await simResponse;
    assert.equal(sim.status(), 200);
    const simulation = await sim.json();
    await page.locator('.risk').waitFor();
    await screenshot('04-digital-twin-simulation.png');
    record('Simulation button executes backend and displays result', simulation);

    await page.getByRole('link', { name: 'Optimisation', exact: true }).click();
    const optResponse = page.waitForResponse(r => r.url().endsWith('/optimisations') && r.request().method() === 'POST');
    await page.getByRole('button', { name: 'Generate recommendation' }).click();
    const opt = await optResponse;
    assert.equal(opt.status(), 200);
    const optimisation = await opt.json();
    await page.getByText('Pending human approval').waitFor();
    await screenshot('05-resource-optimisation.png');
    record('Optimisation generates advisory recommendation', optimisation);

    for (const [label, heading] of [['Capacity', 'Capacity snapshots'], ['Policies', 'Operational policies']]) {
      await page.getByRole('link', { name: label, exact: true }).click();
      await page.getByRole('heading', { name: heading, exact: true }).waitFor();
      record(`${label} page renders`, await page.locator('main').innerText());
    }
    await page.getByRole('link', { name: 'Operations Intelligence', exact: true }).click();
    const intelResponse = page.waitForResponse(r => r.url().endsWith('/operations-intelligence') && r.request().method() === 'POST');
    await page.getByRole('button', { name: 'Ask Operations Intelligence', exact: true }).click();
    const intel = await intelResponse;
    assert.equal(intel.status(), 200);
    const intelligence = await intel.json();
    await page.locator('.response .pill').waitFor();
    record('Operations Intelligence availability handling', intelligence);

    await page.getByRole('link', { name: 'Forecasting', exact: true }).click();
    await page.getByRole('button', { name: 'Generate hospital prediction' }).click();
    assert.equal(await page.locator('.error').innerText(), 'Enter the hospital name.');
    record('Frontend empty hospital validation', 'Prediction blocked with inline error');
    await page.getByLabel('Hospital name', { exact: true }).fill('City General Hospital (Test Data)');
    await page.getByLabel('Internal identifier', { exact: true }).fill('DEMO-HOSP-01');
    await page.getByRole('button', { name: 'Generate hospital prediction' }).click();
    assert.equal(await page.locator('.error').innerText(), 'Complete every monthly field before running the prediction.');
    record('Frontend missing monthly fields validation', 'Prediction blocked with inline error');
    await page.locator('input[type=file]').setInputFiles(path.join(root, 'sample_data/hospital_prediction_test.csv'));
    await page.waitForFunction(() => document.querySelector('[aria-label="Emergency admissions 13"]')?.value === '4345');
    assert.equal(await page.getByLabel('Emergency admissions 13', { exact: true }).inputValue(), '4345');
    assert.equal(await page.locator('tbody tr').count(), 13);
    await page.setViewportSize({ width: 1600, height: 1560 });
    await page.evaluate(() => window.scrollTo(0, 0));
    await screenshot('06-forecast-input-data.png');
    await page.setViewportSize({ width: 1600, height: 1100 });
    const predictionResponse = page.waitForResponse(r => r.url().endsWith('/forecasts/hospital') && r.request().method() === 'POST');
    await page.getByRole('button', { name: 'Generate hospital prediction' }).click();
    const predictionHttp = await predictionResponse;
    assert.equal(predictionHttp.status(), 200);
    const prediction = await predictionHttp.json();
    await page.locator('.forecast-result strong').waitFor();
    assert.equal((await page.locator('.forecast-result strong').innerText()).replaceAll(',', ''), String(prediction.predicted_emergency_admissions));
    assert.equal(prediction.target_month, '2026-08');
    await page.locator('.forecast-output').scrollIntoViewIfNeeded();
    await screenshot('07-forecast-prediction-result.png', false);
    record('CSV input to real model prediction and UI/API parity', prediction);
    const runs = await jsonGet('/forecasts/history');
    assert.ok(runs.some(r => r.id === prediction.forecast_run_id && r.displayed_prediction === prediction.predicted_emergency_admissions));
    record('Prediction persisted and retrievable', prediction.forecast_run_id);
    const payload = predictionHttp.request().postDataJSON();
    for (const [name, mutate] of [
      ['Fewer than 13 months', p => p.history.pop()],
      ['Duplicate months', p => p.history[1].month = p.history[0].month],
      ['Negative admissions', p => p.history[0].emergency_admissions = -1],
      ['Impossible four-hour attendance count', p => p.history[0].attendances_under_4_hours = 999999],
    ]) {
      const altered = structuredClone(payload); mutate(altered);
      const r = await context.request.post(`${api}/api/v1/forecasts/hospital`, { headers, data: altered });
      assert.equal(r.status(), 422, name);
      record(`API validation: ${name}`, 'HTTP 422');
    }
    await fs.writeFile(path.join(output, 'prediction-input.json'), JSON.stringify(payload, null, 2));
    await fs.writeFile(path.join(output, 'prediction-output.json'), JSON.stringify(prediction, null, 2));

    await page.setViewportSize({ width: 390, height: 844 });
    await page.goto(web);
    await page.getByRole('heading', { name: 'Good morning, operations team' }).waitFor();
    const mobileOverflow = await page.evaluate(() => ({ viewport: innerWidth, document: document.documentElement.scrollWidth }));
    record('Mobile dashboard layout inspected', mobileOverflow);
    await page.locator('button.menu').click();
    await page.getByRole('link', { name: 'Forecasting', exact: true }).click();
    await page.getByRole('heading', { name: 'Next-month emergency admissions' }).waitFor();
    record('Mobile menu navigation', 'Forecast page opened at 390px width');
    await page.setViewportSize({ width: 1600, height: 1100 });
    await page.getByRole('button', { name: 'Sign out', exact: true }).click();
    await page.getByRole('heading', { name: 'Welcome to HealthFlow' }).waitFor();
    assert.equal(await page.evaluate(() => localStorage.getItem('healthflow_token')), null);
    record('Sign out clears browser session', 'Login shown and token removed');
  } catch (error) {
    issues.push({ type: 'harness', message: error.stack });
    await screenshot('debug-failure.png').catch(() => {});
    throw error;
  } finally {
    await fs.writeFile(path.join(output, 'verification-results.json'), JSON.stringify({ date: '2026-11-08', checks, issues }, null, 2));
    await browser.close();
  }
})().catch(err => { console.error(err); process.exitCode = 1; });
